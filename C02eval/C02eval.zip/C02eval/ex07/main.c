#include <stdio.h>

char	*ft_strupcase(char *str);

int	main()
{
	char str[] = "mynameisrudi";
	printf("%s", ft_strupcase(str));
}
