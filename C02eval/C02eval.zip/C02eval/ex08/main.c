#include <stdio.h>

char	*ft_strlowcase(char *str);

int	main()
{
	char str[] = "MYNAMEISRUDI";
	printf("%s", ft_strlowcase(str));
}
