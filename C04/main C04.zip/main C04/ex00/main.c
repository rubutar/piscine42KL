#include <stdio.h>
int	ft_strlen(char *str);
int main (void)
{
	printf("length of the 'hello world' is %d\n \n", ft_strlen("hello world"));
	printf("length of the '' is %d", ft_strlen(""));	
}
