#include <unistd.h>

void	ft_putstr(char *str);
 
int	main()
 {
 	ft_putstr("Hello World!");
 }
 
